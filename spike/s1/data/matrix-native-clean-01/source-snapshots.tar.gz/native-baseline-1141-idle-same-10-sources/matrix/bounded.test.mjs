import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { buildMatrixBounded } from "./bounded.mjs";

test("an individually selected native variant compares against its matching reference", async () => {
  const code = buildMatrixBounded(
    readFileSync(new URL("../bounded-gates.mjs", import.meta.url)),
  );
  const { runBoundedGate } = await import(
    "data:text/javascript;base64," + Buffer.from(code).toString("base64")
  );
  const text = "alpha beta\ndelta epsilon\n";
  const before = {
    viewColumn: 2,
    text,
    selections: [[0, 0, 0, 0]],
    mode: 0,
    pending: {},
    registers: {},
    leader: { active: false, events: [] },
    sentinel: "normal-editor-capture-off",
    sentinelSequence: 0,
  };
  const expected = (key) => ({
    ...structuredClone(before),
    text:
      key === "r" ? " " + text.slice(1) : key === "d" ? text.slice(1) : text,
    selections: key === "f" ? [[0, 5, 0, 5]] : [[0, 0, 0, 0]],
  });
  const reference = {
    gate: "native-baseline",
    status: "native-baseline-recorded",
    node: "fixture",
    product: {},
    vimBundleSha256: "fixture",
    condition: {},
    settings: {},
    trials: [0, 1].flatMap((round) =>
      ["f", "r", "d"].map((key) => ({
        round,
        case: key + "-space",
        before,
        after: expected(key),
      })),
    ),
  };
  const root = mkdtempSync(join(tmpdir(), "s1-native-case-test-"));
  try {
    const file = join(root, "reference.json");
    writeFileSync(file, JSON.stringify(reference));
    for (const key of ["r", "d"]) {
      let state = structuredClone(before),
        sequence = 0;
      const result = {
        node: "fixture",
        product: {},
        vimBundleSha256: "fixture",
        condition: {},
        settings: {},
        trials: [],
      };
      await runBoundedGate({
        gate: "native",
        result,
        reference,
        referencePath: file,
        matrixCase: key + "-space",
        matrixPhase: async () => 0,
        text,
        noPending: () => true,
        save() {},
        call: async () => {
          state = structuredClone(before);
        },
        settled: async () => ({
          ...structuredClone(state),
          sentinelSequence: sequence,
        }),
        inject: (keys) => {
          if (keys[0] === "ctrl+alt+9") sequence++;
          else {
            assert.deepEqual(keys, [key, "space"]);
            state = expected(key);
          }
        },
      });
      assert.equal(result.status, "native-gate-passed");
      assert.equal(result.trials.length, 1000);
      assert.ok(
        result.trials.every(
          (trial) => trial.case === key + "-space" && !trial.errors.length,
        ),
      );
    }
  } finally {
    rmSync(root, { recursive: true });
  }
});
