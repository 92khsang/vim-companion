const { execFileSync } = require("node:child_process");
const samples = [];
let last;
const observe = () => {
  const requestedAt = performance.now();
  try {
    const id = execFileSync("xdotool", ["getwindowfocus"], { encoding: "utf8", timeout: 1000 }).trim();
    const observedAt = performance.now();
    if (id !== last) {
      last = id;
      let name;
      try { name = execFileSync("xdotool", ["getwindowname", id], { encoding: "utf8", timeout: 1000 }).trim(); } catch {}
      samples.push({ requestedAt, observedAt, id, name });
    }
  } catch (error) { samples.push({ requestedAt, error: String(error) }); }
};
observe();
const timer = setInterval(observe, 25);
process.send({ ready: true, timeOrigin: performance.timeOrigin, pid: process.pid });
process.on("message", (message) => {
  if (message === "stop") {
    clearInterval(timer); observe();
    process.send({ samples, timeOrigin: performance.timeOrigin }, () => process.exit(0));
  }
});
process.on("disconnect", () => process.exit(0));
