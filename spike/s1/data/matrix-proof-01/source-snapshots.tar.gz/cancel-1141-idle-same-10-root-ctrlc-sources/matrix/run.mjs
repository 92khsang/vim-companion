import assert from "node:assert/strict";
import {
  mkdtempSync,
  readFileSync,
  writeFileSync,
  existsSync,
  cpSync,
  mkdirSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { spawn, execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";

const source = resolve(import.meta.dirname, "..");
const output = resolve(process.argv[2] ?? "spike/s1/data/matrix-entry.json");
const sources = output.replace(/\.json$/, "") + "-sources";
assert.ok(
  !existsSync(output) && !existsSync(sources),
  "choose unused result and source paths",
);
assert.ok(!process.env.S1_GATE, "matrix selects its own retained gate");
assert.ok(
  !process.env.S1_DIAG_ONLY &&
    !process.env.S1_TRACE &&
    !process.env.S1_BINDINGS,
  "matrix does not accept diagnostic overrides",
);
const options = {
  row: process.env.S1_MATRIX_ROW ?? "entry-exit",
  version: process.env.S1_MATRIX_VERSION,
  affinity: process.env.S1_AFFINITY ?? "same",
  editContext: process.env.S1_EDIT_CONTEXT !== "false",
  case: process.env.S1_MATRIX_CASE,
  instances: Number(process.env.S1_INSTANCES ?? 1),
  cpuSet: process.env.S1_CPUS,
};
assert.ok(Number.isSafeInteger(options.instances) && options.instances >= 1);
if (options.instances > 1)
  assert.ok(options.cpuSet, "parallel instances require separate CPU sets");
if (options.cpuSet)
  assert.match(options.cpuSet, /^\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*$/);
if (options.case) {
  assert.equal(options.row, "cancel");
  assert.ok(
    [
      "root-escape",
      "root-ctrl+[",
      "root-ctrl+c",
      "w-escape",
      "w-ctrl+[",
      "w-ctrl+c",
    ].includes(options.case),
  );
}
assert.ok(
  process.env.S1_EDIT_CONTEXT === undefined ||
    ["true", "false"].includes(process.env.S1_EDIT_CONTEXT),
);
mkdirSync(sources, { recursive: true });
// All runtime imports and installation reads use this immutable snapshot.
for (const name of [
  "run.mjs",
  "bounded-gates.mjs",
  "matrix",
  "leader",
  "probe",
  "load",
  "ready",
  "dock",
])
  cpSync(join(source, name), join(sources, name), { recursive: true });
const { buildMatrixRunner } = await import(
  pathToFileURL(join(sources, "matrix/runner.mjs")).href
);
const { buildMatrixBounded } = await import(
  pathToFileURL(join(sources, "matrix/bounded.mjs")).href
);
options.observe = ["entry-exit", "query"].includes(options.row);
const baseline = readFileSync(join(sources, "run.mjs"));
const temporary = mkdtempSync(join(tmpdir(), "s1-matrix-runner-"));
const bounded = join(temporary, "bounded-gates.mjs");
writeFileSync(
  bounded,
  buildMatrixBounded(readFileSync(join(sources, "bounded-gates.mjs"))),
);
const generated = buildMatrixRunner(
  baseline,
  sources,
  options,
  pathToFileURL(bounded).href,
);
const script = join(temporary, "run.mjs");
writeFileSync(script, generated.code);
execFileSync(process.execPath, ["--check", script]);
writeFileSync(
  join(sources, "matrix-options.json"),
  JSON.stringify(
    { ...options, runnerBaselineSha256: generated.baselineSha256 },
    null,
    2,
  ) + "\n",
);
const child = spawn(
  options.cpuSet ? "taskset" : process.execPath,
  options.cpuSet
    ? ["--cpu-list", options.cpuSet, process.execPath, script, output]
    : [script, output],
  {
    env: { ...process.env, S1_GATE: options.row },
    stdio: "inherit",
  },
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => child.kill(signal));
const status = await new Promise((resolve, reject) => {
  child.once("error", reject);
  child.once("exit", (code) => resolve(code ?? 1));
});
process.exitCode = status;
