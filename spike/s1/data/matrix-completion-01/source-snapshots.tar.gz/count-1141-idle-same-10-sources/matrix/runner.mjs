import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { join } from "node:path";

export const versions = {
  "1.134.0": "110a328ea54b42367b803ec53ee0bf52ef26b419",
  "1.141.0": "2a59476c9bfc",
};

export function buildMatrixRunner(baseline, source, options, boundedUrl) {
  assert.ok(Object.hasOwn(versions, options.version));
  assert.ok(["same", "separate"].includes(options.affinity));
  assert.ok(
    [
      "entry-exit",
      "cancel",
      "native",
      "native-baseline",
      "query",
      "count",
      "visual",
      "visual-baseline",
    ].includes(options.row ?? "entry-exit"),
  );
  assert.equal(typeof options.editContext, "boolean");
  let code = baseline.toString();
  const replace = (before, after) => {
    assert.equal(
      code.split(before).length,
      2,
      "matrix runner hook must be unique: " + before,
    );
    code = code.replace(before, after);
  };
  // Imports and resource paths in this temporary runner still point to the
  // retained source tree. Existing entrypoints and guards are never rewritten.
  code = code.replace(
    /from "(\.\/[^\"]+)"/g,
    (_match, path) =>
      "from " + JSON.stringify(pathToFileURL(join(source, path)).href),
  );
  replace(
    "const source = import.meta.dirname;",
    "const source = " + JSON.stringify(source) + ";",
  );
  code =
    `import { installMatrix } from ${JSON.stringify(pathToFileURL(join(source, "matrix/install.mjs")).href)};\nconst matrixOptions = ${JSON.stringify(options)};\n` +
    code;
  code =
    `import { connectMatrixObserver, clockSamples } from ${JSON.stringify(pathToFileURL(join(source, "matrix/observer.mjs")).href)};\nlet matrixObserver;\n` +
    code;
  replace(
    "  if (visualDiagnostic) {\n    const reservation",
    "  if (matrixOptions.observe) {\n    const reservation",
  );
  replace(
    "      ...(visualDiagnostic\n        ? [",
    "      ...(matrixOptions.observe\n        ? [",
  );
  replace(
    '  result.initial = await call("warm");',
    `  result.initial = await call("warm");
  if (matrixOptions.observe) {
    matrixObserver = await connectMatrixObserver({port: debugPort, until});
    result.matrix.renderer = matrixObserver.metadata;
    result.matrix.clocksBefore = {
      renderer: await clockSamples(() => matrixObserver.clock()),
      hosts: await clockSamples(() => call("clock")),
    };
  }`,
  );
  replace(
    "      let phaseDelayMs = 0;",
    "      const rendererBefore = await matrixObserver.begin();\n      let phaseDelayMs = 0;",
  );
  replace(
    "      const sentinel = await settled();\n      const errors = [];",
    "      const sentinel = await settled();\n      const rendererAfter = await matrixObserver.read();\n      const errors = [];",
  );
  replace(
    "        phaseDelayMs,\n        injectedAt,",
    "        phaseDelayMs,\n        renderer: { before: rendererBefore, after: rendererAfter },\n        injectedAt,",
  );
  replace(
    '  result.loadWindows = await call("loadWindows");',
    `  result.loadWindows = await call("loadWindows");
  if (matrixObserver) result.matrix.clocksAfter = {
    renderer: await clockSamples(() => matrixObserver.clock()),
    hosts: await clockSamples(() => call("clock")),
  };`,
  );
  replace(
    "  observer?.close();",
    "  observer?.close();\n  matrixObserver?.close();",
  );
  replace(
    '    "entry-exit",\n    "cancel",',
    '    "entry-exit",\n    "query",\n    "count",\n    "visual",\n    "visual-baseline",\n    "cancel",',
  );
  code =
    `import { runQuery } from ${JSON.stringify(pathToFileURL(join(source, "matrix/query.mjs")).href)};\n` +
    code;
  replace(
    '  } else if (gate !== "entry-exit") {',
    `  } else if (gate === "query") {
    await runQuery({result, call, inject, settled, noPending, save, text, observer: matrixObserver,
      phase: async () => {
        if (!loaded) return 0;
        phaseSeed = (Math.imul(1664525, phaseSeed) + 1013904223) >>> 0;
        const delay = phaseSeed % 100;
        await sleep(delay);
        return delay;
      },
    });
  } else if (gate !== "entry-exit") {`,
  );
  replace(
    "  processes.push(ide);",
    `  processes.push(ide);
  result.matrix.ideLauncher = {pid: ide.pid};
  ide.once("spawn", () => { result.matrix.ideLauncher.started = new Date().toISOString(); });
  ide.once("exit", (code, signal) => { result.matrix.ideLauncher.finished = new Date().toISOString(); result.matrix.ideLauncher.exit = {code, signal}; });`,
  );
  replace(
    "  result.finished = new Date().toISOString();\n  save();",
    "  // Save only after the owned IDE launcher has exited.",
  );
  replace(
    "  console.log(`Saved ${output}; sandbox logs retained at ${root}`);",
    `  if (result.matrix?.ideLauncher) {
    const cleanupDeadline = Date.now() + 5000;
    while (!result.matrix.ideLauncher.finished && Date.now() < cleanupDeadline) await sleep(25);
    if (!result.matrix.ideLauncher.finished) {
      result.cleanupError = "IDE launcher did not exit within five seconds";
      result.status = "harness-error";
      process.exitCode = 1;
    }
  }
  result.finished = new Date().toISOString();
  save();
  console.log(\`Saved \${output}; sandbox logs retained at \${root}\`);`,
  );
  replace(
    '      readFileSync(join(source, "probe/package.json"), "utf8"),',
    '      readFileSync(join(extensions, "vim-companion-spike.s1-probe-0.0.0/package.json"), "utf8"),',
  );
  replace(
    '  const pattern =\n    gate === "entry-exit"',
    '  const pattern = gate === "count" ? ["3", "space", "b", "n", "j"] :\n    gate === "entry-exit"',
  );
  code =
    `import { runCount } from ${JSON.stringify(pathToFileURL(join(source, "matrix/count.mjs")).href)};\n` +
    code;
  replace(
    '  } else if (gate === "query") {\n    await runQuery({result, call, inject, settled, noPending, save, text, observer: matrixObserver,',
    '  } else if (["query", "count"].includes(gate)) {\n    await (gate === "count" ? runCount : runQuery)({result, call, inject, settled, noPending, save, text, workspace, file, observer: matrixObserver,',
  );
  replace(
    'const baseline = gate === "native-baseline";',
    'const baseline = ["native-baseline", "visual-baseline"].includes(gate);',
  );
  code =
    `import { runVisual } from ${JSON.stringify(pathToFileURL(join(source, "matrix/visual.mjs")).href)};\n` +
    code;
  replace(
    '  } else if (["query", "count"].includes(gate)) {',
    `  } else if (["visual", "visual-baseline"].includes(gate)) {
    await runVisual({result,call,inject,settled,noPending,save,referencePath,
      phase:async()=>{
        if(!loaded)return 0;
        phaseSeed=(Math.imul(1664525,phaseSeed)+1013904223)>>>0;
        const delay=phaseSeed%100;await sleep(delay);return delay;
      },
    });
  } else if (["query", "count"].includes(gate)) {`,
  );
  replace(
    `  if (baseline) {
    const path = join(
      extensions,
      "vim-companion-spike.s1-probe-0.0.0/package.json",
    );
    const probeManifest = JSON.parse(readFileSync(path, "utf8"));
    probeManifest.extensionDependencies = ["vscodevim.vim"];
    writeFileSync(path, JSON.stringify(probeManifest));
  }`,
    "  // The matrix installer finalizes dependencies before recording hashes.",
  );
  if (boundedUrl) {
    replace(
      JSON.stringify(pathToFileURL(join(source, "bounded-gates.mjs")).href),
      JSON.stringify(boundedUrl),
    );
    replace(
      "      referencePath,\n      call,",
      `      referencePath,
      matrixCase: matrixOptions.case,
      matrixPhase: async () => {
        if (!loaded) return 0;
        phaseSeed = (Math.imul(1664525, phaseSeed) + 1013904223) >>> 0;
        const delay = phaseSeed % 100;
        await sleep(delay);
        return delay;
      },
      call,`,
    );
  }
  replace(
    'assert.ok(gate === "entry-exit" || (!loaded && delayMs === 10));',
    'assert.ok(["entry-exit", "cancel", "native", "native-baseline", "query", "count", "visual", "visual-baseline"].includes(gate), "unsupported matrix row");',
  );
  replace(
    '  assert.equal(result.product.version, "1.141.0");',
    `  assert.equal(result.product.version, matrixOptions.version);
  assert.ok(result.product.commit.startsWith(${JSON.stringify(versions[options.version])}), "unexpected IDE build");`,
  );
  replace(
    "  if (boundary || visualDiagnostic) {",
    "  installMatrix({ source, extensions, result, options: matrixOptions });\n  if (boundary || visualDiagnostic) {",
  );
  replace(
    '    "editor.editContext": true,',
    '    "editor.editContext": matrixOptions.editContext,',
  );
  replace(
    "    const same = JSON.stringify(previous) === JSON.stringify(value);",
    `    const comparable = (snapshot) => snapshot && { ...snapshot, matrixObservation: undefined };
    const same = JSON.stringify(comparable(previous)) === JSON.stringify(comparable(value));`,
  );
  replace(
    "    return same && idle(value) ? value : false;",
    "    return same && idle(value) && value.matrixObservation.engineStable ? value : false;",
  );
  replace(
    '      check(after.viewColumn === 1, "left group not active");',
    `      const arrivals = rendererAfter.events.filter((event) => event.type === "keydown" && !event.ctrl && !event.alt && !event.meta);
      check(rendererAfter.overflow === 0, "renderer event overflow");
      check(JSON.stringify(arrivals.map((event) => event.key)) === JSON.stringify([" ", "w", "h", "j"]), "renderer did not observe the exact injected sequence");
      check(arrivals.slice(0, 3).every((event) => event.target?.editor && !event.target?.quickInput), "editor DOM focus was lost before the leaf");
      check(!rendererAfter.events.some((event) => event.type === "window-blur"), "IDE window lost focus during the trial");
      check(after.viewColumn === 1, "left group not active");`,
  );
  replace(
    '      check(after.viewColumn === 1, "left group not active");',
    `      check(
        JSON.stringify({ ...after, matrixObservation: undefined, sentinel: undefined, sentinelSequence: undefined }) ===
        JSON.stringify({ ...sentinel, matrixObservation: undefined, sentinel: undefined, sentinelSequence: undefined }),
        "state changed before final sentinel",
      );
      check(after.viewColumn === 1, "left group not active");`,
  );
  replace(
    "        finalSentinel: sentinel.sentinel,",
    "        finalSnapshot: sentinel,\n        finalSentinel: sentinel.sentinel,",
  );
  replace(
    "  result.settings = settings;",
    `  settings["extensions.experimental.affinity"] = matrixOptions.affinity === "separate"
    ? { "vim-companion-spike.s1-leader": 1 } : {};
  result.scope = "S1 " + (matrixOptions.row ?? "entry-exit") + " environment matrix; first-discrepancy stop; other required rows remain separate";
  result.condition.affinity = matrixOptions.affinity === "separate" ? "separate extension hosts" : "same extension host";
  result.condition.instances = matrixOptions.instances ?? 1;
  result.condition.instanceCountMeaning = "configured maximum; batch overlap intervals recorded separately";
  result.condition.cpuAffinity = readFileSync("/proc/self/status", "utf8").match(/^Cpus_allowed_list:\\s*(.*)$/m)?.[1];
  result.settings = settings;`,
  );
  replace(
    "  else assert.equal(result.hello.pid, result.hello.leaderPid);",
    `  else if (matrixOptions.affinity === "separate") assert.notEqual(result.hello.pid, result.hello.leaderPid, "companion must run in a separate host");
  else assert.equal(result.hello.pid, result.hello.leaderPid);`,
  );
  return {
    code,
    baselineSha256: createHash("sha256").update(baseline).digest("hex"),
  };
}
