import test from "node:test";
import assert from "node:assert/strict";
import {
  clockOffset,
  latency,
  insideWait,
  firstFocus,
  commandTiming,
  observationWindow,
} from "./focus-analysis.mjs";
import { rendererTimeErrorMs } from "./fault.mjs";
import { focusKind } from "./focus.mjs";

test("focus clock bounds retain quantization uncertainty and reject epoch changes", () => {
  const samples = [
    { sent: 10, received: 10.02, remote: { time: 0, timeOrigin: 100 } },
    { sent: 20.05, received: 20.07, remote: { time: 10, timeOrigin: 100 } },
  ];
  assert.equal(clockOffset(samples), null);
  const offset = clockOffset(samples, null, rendererTimeErrorMs);
  assert.ok(offset.lower <= offset.upper);
  const mismatch = structuredClone(samples);
  mismatch[1].remote.timeOrigin++;
  assert.equal(clockOffset(mismatch, null, rendererTimeErrorMs), null);
  assert.deepEqual(latency({ lower: 5, upper: 7 }, { lower: 6, upper: 8 }), {
    lowerMs: -3,
    upperMs: 1,
  });
});
test("provider wait evidence requires strict containment of the whole key interval", () => {
  const request = { lower: 0, upper: 2 },
    response = { lower: 200, upper: 203 };
  assert.equal(
    insideWait({ lower: 10, upper: 11 }, request, response),
    "proven inside",
  );
  assert.equal(
    insideWait({ lower: 1, upper: 3 }, request, response),
    "clock bounds overlap",
  );
  assert.equal(
    insideWait({ lower: -5, upper: -1 }, request, response),
    "before request",
  );
  assert.equal(insideWait(null, request, response), "unobserved");
});
test("a focused list inside Quick Open remains a list target", () => {
  assert.equal(
    focusKind({ quickInput: true, role: "listbox", tag: "DIV" }),
    "list or tree",
  );
  assert.equal(focusKind({ quickInput: true, tag: "INPUT" }), "text input");
});

test("first focus compares native and DOM intervals without inventing no-change results", () => {
  const native = {
    observed: true,
    bounds: { lowerMs: 5, upperMs: 8 },
    source: "native",
  };
  const dom = {
    observed: true,
    bounds: { lowerMs: 12, upperMs: 13 },
    source: "DOM",
  };
  assert.equal(firstFocus([dom, native]).source, "native");
  const overlap = firstFocus([
    dom,
    { ...native, bounds: { lowerMs: 11, upperMs: 15 } },
  ]);
  assert.equal(overlap.source, "DOM or native");
  assert.deepEqual(overlap.bounds, { lowerMs: 11, upperMs: 13 });
  const unknown = firstFocus([{ ...native, bounds: null }]);
  assert.equal(unknown.observed, true);
  assert.equal(unknown.bounds, null);
});
test("pending commands and observation tails retain the exact five-second boundary", () => {
  assert.equal(
    commandTiming(
      10,
      { t: 5011, type: "leaf-end" },
      { lowerMs: 20, upperMs: 21 },
    ).status,
    "none within 5 s",
  );
  assert.equal(
    commandTiming(10, null, { lowerMs: 20, upperMs: 21 }).jWhilePending,
    "proven before settlement; pending at 5 s",
  );
  assert.equal(
    observationWindow({ lowerMs: 4999, upperMs: 5001 }),
    "boundary overlap",
  );
  assert.equal(
    observationWindow({ lowerMs: 5001, upperMs: 5002 }),
    "after 5 s",
  );
});
