import test from "node:test";
import assert from "node:assert/strict";
import { clockOffset, latency, insideWait } from "./focus-analysis.mjs";
import { rendererTimeErrorMs } from "./fault.mjs";
import { focusKind } from "./focus.mjs";

test("focus clock bounds retain quantization uncertainty and reject epoch changes", () => {
  const samples = [
    { sent: 10, received: 10.02, remote: { time: 0, timeOrigin: 100 } },
    { sent: 20.05, received: 20.07, remote: { time: 10, timeOrigin: 100 } },
  ];
  assert.equal(clockOffset(samples), null);
  const offset = clockOffset(samples, null, rendererTimeErrorMs);
  assert.ok(offset.lower <= offset.upper);
  const mismatch = structuredClone(samples);
  mismatch[1].remote.timeOrigin++;
  assert.equal(clockOffset(mismatch, null, rendererTimeErrorMs), null);
  assert.deepEqual(latency({ lower: 5, upper: 7 }, { lower: 6, upper: 8 }), {
    lowerMs: -3,
    upperMs: 1,
  });
});
test("provider wait evidence requires strict containment of the whole key interval", () => {
  const request = { lower: 0, upper: 2 },
    response = { lower: 200, upper: 203 };
  assert.equal(
    insideWait({ lower: 10, upper: 11 }, request, response),
    "proven inside",
  );
  assert.equal(
    insideWait({ lower: 1, upper: 3 }, request, response),
    "clock bounds overlap",
  );
  assert.equal(
    insideWait({ lower: -5, upper: -1 }, request, response),
    "before request",
  );
  assert.equal(insideWait(null, request, response), "unobserved");
});
test("a focused list inside Quick Open remains a list target", () => {
  assert.equal(
    focusKind({ quickInput: true, role: "listbox", tag: "DIV" }),
    "list or tree",
  );
  assert.equal(focusKind({ quickInput: true, tag: "INPUT" }), "text input");
});
