import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { rendererTimeErrorMs } from "./fault.mjs";
import { focusKind } from "./focus.mjs";

export function clockOffset(samples, member, error = 0) {
  const values = samples.map((sample) => ({
    ...sample,
    value: member ? sample.remote[member] : sample.remote,
  }));
  if (
    !values.length ||
    values.some((sample) => !sample.value) ||
    new Set(values.map((sample) => sample.value.timeOrigin)).size !== 1
  )
    return null;
  const lower = Math.max(
    ...values.map((sample) => sample.sent - sample.value.time - error),
  );
  const upper = Math.min(
    ...values.map((sample) => sample.received - sample.value.time + error),
  );
  return lower <= upper
    ? { lower, upper, timeOrigin: values[0].value.timeOrigin }
    : null;
}
const local = (time, offset, error = 0) =>
  offset && {
    lower: time + offset.lower - error,
    upper: time + offset.upper + error,
  };
export const latency = (event, start) =>
  event &&
  start && {
    lowerMs: event.lower - start.upper,
    upperMs: event.upper - start.lower,
  };
const quantiles = (values) => {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return Object.fromEntries(
    [
      ["median", 0.5],
      ["p95", 0.95],
      ["maximum", 1],
    ].map(([key, q]) => [key, sorted[Math.ceil(sorted.length * q) - 1]]),
  );
};
const counts = (values) =>
  Object.fromEntries(
    [...new Set(values)].map((value) => [
      value,
      values.filter((item) => item === value).length,
    ]),
  );
const intervalStats = (values) => ({
  count: values.length,
  lowerMs: quantiles(values.map((value) => value.lowerMs)),
  upperMs: quantiles(values.map((value) => value.upperMs)),
});
export function insideWait(key, request, response) {
  if (!key || !request || !response) return "unobserved";
  if (key.lower > request.upper && key.upper < response.lower)
    return "proven inside";
  if (key.upper < request.lower) return "before request";
  if (key.lower > response.upper) return "after response";
  return "clock bounds overlap";
}

function providerAnalysis(raw, trial, offsets, keyBounds, start) {
  const methods = {
    "delayed-cq": "textDocument/codeAction",
    "delayed-cr": "textDocument/prepareRename",
    "delayed-cf": "textDocument/formatting",
    "delayed-cd": "textDocument/hover",
  };
  const method = methods[trial.scenario];
  if (!method) return null;
  const records = [];
  for (const [name, provider] of Object.entries(trial.providerEvents)) {
    const offset =
      provider.pid === raw.hello.pid
        ? offsets.probe
        : provider.pid === raw.hello.leaderPid
          ? offsets.leader
          : null;
    const clientOffset =
      offset?.timeOrigin === provider.timeOrigin ? offset : null;
    const relations = [];
    for (const request of provider.events.filter(
      (event) => event.type === "request",
    )) {
      const received = provider.server.find(
        (event) => event.type === "request" && event.id === request.id,
      );
      const response = provider.events.find(
        (event) => event.type === "response" && event.id === request.id,
      );
      const sent = provider.server.find(
        (event) =>
          event.id === request.id &&
          (event.type === "response" ||
            (event.type === "cancel" && response?.error?.code === -32800)),
      );
      if (received && response && sent)
        relations.push({
          lower: request.time - received.time,
          upper: response.time - sent.time,
        });
    }
    const relative = relations.length && {
      lower: Math.max(...relations.map((value) => value.lower)),
      upper: Math.min(...relations.map((value) => value.upper)),
    };
    const serverOffset =
      relative &&
      relative.lower <= relative.upper &&
      clientOffset &&
      new Set(provider.server.map((event) => event.timeOrigin)).size === 1
        ? {
            lower: relative.lower + clientOffset.lower,
            upper: relative.upper + clientOffset.upper,
          }
        : null;
    for (const request of provider.events.filter(
      (event) =>
        event.type === "request" &&
        event.method === method &&
        event.trial === `${trial.scenario}:${trial.round}`,
    )) {
      const requestBounds = local(request.time, clientOffset);
      if (requestBounds && start && requestBounds.upper < start.lower) continue;
      const response = provider.events.find(
        (event) => event.type === "response" && event.id === request.id,
      );
      const received = provider.server.find(
        (event) => event.type === "request" && event.id === request.id,
      );
      const sent = provider.server.find(
        (event) =>
          event.id === request.id &&
          (event.type === "response" ||
            (event.type === "cancel" && response?.error?.code === -32800)),
      );
      records.push({
        provider: name,
        clientPid: provider.pid,
        serverPid: provider.serverPid,
        id: request.id,
        method,
        commandRequestOrder:
          requestBounds && start && requestBounds.lower >= start.upper
            ? "after command start"
            : "unresolved",
        triggerKind: received?.params?.context?.triggerKind,
        clientWaitMs: response ? response.time - request.time : null,
        serverResponseDelayMs: sent?.delayMs ?? null,
        response: response?.error
          ? "cancelled/error " + response.error.code
          : response
            ? "completed"
            : "pending at observation end",
        jDuringClientWait: insideWait(
          keyBounds,
          requestBounds,
          response && local(response.time, clientOffset),
        ),
        jDuringServerWait: insideWait(
          keyBounds,
          received && local(received.time, serverOffset),
          sent && local(sent.time, serverOffset),
        ),
        serverClockOffset: serverOffset,
      });
    }
  }
  const keys = trial.renderer.events.filter(
    (event) =>
      event.type === "keydown" &&
      event.key === "j" &&
      !event.ctrl &&
      !event.alt &&
      !event.meta,
  );
  const leaderKeys = trial.after.leader.events.filter(
    (event) => event.type === "key" && event.value === "j",
  );
  const selection = trial.after.selections;
  const moved = JSON.stringify(selection) === JSON.stringify([[1, 0, 1, 0]]);
  return {
    requests: records,
    keydowns: keys.length,
    keyTarget: keys.length === 1 ? focusKind(keys[0].target) : "unknown",
    route: leaderKeys.length
      ? "leader handler"
      : keys.length !== 1
        ? "unknown"
        : focusKind(keys[0].target) !== "editor text"
          ? "DOM " + focusKind(keys[0].target)
          : moved
            ? "inferred Vim line movement"
            : "editor DOM; engine effect unresolved",
    leaderKeys,
    finalSelections: selection,
    inputs: trial.renderer.inputs.map(({ value, focused, label }) => ({
      value,
      focused,
      label,
    })),
  };
}

export function analyzeFocusTrial(raw, trial) {
  const samples = (kind) => [
    ...trial.clocksBefore[kind],
    ...trial.clocksAfter[kind],
  ];
  const offsets = {
    renderer: clockOffset(samples("renderer"), null, rendererTimeErrorMs),
    probe: clockOffset(samples("hosts")),
    leader: clockOffset(samples("hosts"), "leader"),
  };
  const start = local(trial.commandStart.t, offsets.leader);
  const events = trial.renderer.events;
  const baseline = trial.rendererBefore.active?.elementId;
  const departure = events.find(
    (event) =>
      event.type === "window-blur" ||
      (event.type === "focusout" && event.target?.elementId === baseline),
  );
  const arrival = events.find(
    (event) => event.type === "focusin" && event.target?.elementId !== baseline,
  );
  const change = events.find(
    (event) => event === departure || event === arrival,
  );
  const eventLatency = (event) =>
    event &&
    latency(local(event.time, offsets.renderer, rendererTimeErrorMs), start);
  const end = trial.after.leader.events.find(
    (event) =>
      ["leaf-end", "leaf-error"].includes(event.type) &&
      event.id === trial.commandStart.id,
  );
  const widgets = {};
  for (const name of Object.keys(trial.rendererBefore.widgets)) {
    let previous = trial.rendererBefore;
    if (previous.widgets[name]) {
      widgets[name] = { status: "pre-existing" };
      continue;
    }
    for (const sample of trial.renderer.focusSamples ?? []) {
      if (sample.widgets[name]) {
        const low = local(previous.time, offsets.renderer, rendererTimeErrorMs);
        const high = local(sample.time, offsets.renderer, rendererTimeErrorMs);
        widgets[name] = {
          status: "appeared",
          bounds: latency(
            low && high && { lower: low.lower, upper: high.upper },
            start,
          ),
          firstTrueSample: eventLatency(sample),
        };
        break;
      }
      previous = sample;
    }
    widgets[name] ??= { status: "none within observation window" };
  }
  const observedPredicate =
    trial.targetSentinel.sentinel?.sequence ===
    (trial.state.sentinel?.sequence ?? 0) + 1;
  const key = events.filter(
    (event) =>
      event.type === "keydown" &&
      event.key === "j" &&
      !event.ctrl &&
      !event.alt &&
      !event.meta,
  );
  const keyBounds =
    key.length === 1
      ? local(key[0].time, offsets.renderer, rendererTimeErrorMs)
      : null;
  const nativeClocks = trial.native.clocks;
  const nativeOffset =
    nativeClocks &&
    clockOffset([...nativeClocks.before, ...nativeClocks.after]);
  const nativeFirst = trial.native.samples.find(
    (sample, index) =>
      index && sample.id && sample.id !== trial.native.samples[0].id,
  );
  const nativeChange =
    nativeFirst?.previousPoll &&
    nativeOffset &&
    latency(
      {
        lower: nativeFirst.previousPoll.requestedAt + nativeOffset.lower,
        upper: nativeFirst.observedAt + nativeOffset.upper,
      },
      start,
    );
  return {
    index: trial.index,
    scenario: trial.scenario,
    round: trial.round,
    clockOffsets: offsets,
    issues: [
      ...trial.errors,
      ...trial.inconclusive,
      ...Object.entries(offsets)
        .filter(([, value]) => !value)
        .map(([name]) => name + " clock bounds unresolved"),
    ],
    target: trial.modal
      ? "dialog"
      : trial.renderer.documentFocused
        ? focusKind(trial.renderer.active)
        : "other (window unfocused)",
    firstFocusChange: eventLatency(change) ?? nativeChange ?? null,
    firstFocusChangeSource: change
      ? change.type
      : nativeChange
        ? "native poll interval"
        : "none observed",
    firstDeparture: eventLatency(departure) ?? null,
    newTargetFocus: eventLatency(arrival) ?? null,
    nativeFocusChange: nativeChange || null,
    nativeClockMethod: nativeOffset
      ? "bounded IPC round trips"
      : "no bounded native clock samples",
    command: end
      ? {
          status: end.type === "leaf-end" ? "fulfilled" : "rejected",
          elapsedMs: end.t - trial.commandStart.t,
        }
      : { status: "none within 5 s" },
    predicate: observedPredicate
      ? trial.targetSentinel.sentinel.predicate
      : "unobserved",
    captureAtPredicate: observedPredicate
      ? trial.targetSentinel.sentinel.capture
      : "unobserved",
    widgets,
    visibleHover: {
      beforeLeader: trial.beforeLeaderDOM?.widgets.hover,
      preLeaf: trial.preLeafDOM.widgets.hover,
      after: trial.renderer.widgets.hover,
    },
    scmTreeFocus: trial.scmTreeFocus ?? null,
    configure: trial.configure?.renderer && {
      target: focusKind(trial.configure.renderer.active),
      predicate:
        trial.configure.sentinel.sentinel?.sequence ===
        (trial.configure.state.sentinel?.sequence ?? 0) + 1
          ? trial.configure.sentinel.sentinel.predicate
          : "unobserved",
    },
    provider: providerAnalysis(raw, trial, offsets, keyBounds, start),
    jBeforeCommandSettled:
      keyBounds && end && offsets.leader
        ? insideWait(keyBounds, start, local(end.t, offsets.leader))
        : "unobserved/pending",
  };
}

export function analyzeFocus(raw) {
  assert.equal(raw.gate, "focus");
  const trials = raw.trials.map((trial) => analyzeFocusTrial(raw, trial));
  const scenarios = raw.focusProtocol.scenarios.map((scenario) => {
    const rows = trials.filter((trial) => trial.scenario === scenario.id);
    return {
      id: scenario.id,
      leader: scenario.leaf.leader,
      state: scenario.state,
      delayed: scenario.delayed,
      trials: rows.length,
      rounds: [...new Set(rows.map((row) => row.round))],
      issues: rows.filter((row) => row.issues.length).length,
      targets: counts(rows.map((row) => row.target)),
      predicates: counts(rows.map((row) => String(row.predicate))),
      firstFocusChange: intervalStats(
        rows.flatMap((row) =>
          row.firstFocusChange ? [row.firstFocusChange] : [],
        ),
      ),
      noFocusChangeObserved: rows.filter((row) => !row.firstFocusChange).length,
      commandSettlementMs: quantiles(
        rows.flatMap((row) =>
          row.command.elapsedMs === undefined ? [] : [row.command.elapsedMs],
        ),
      ),
      commandOutcomes: counts(rows.map((row) => row.command.status)),
      ...(scenario.delayed
        ? {
            keyRoutes: counts(rows.map((row) => row.provider.route)),
            provenServerWaitTrials: rows.filter((row) =>
              row.provider.requests.some(
                (request) => request.jDuringServerWait === "proven inside",
              ),
            ).length,
          }
        : {}),
    };
  });
  return {
    status: raw.status,
    finished: raw.finished ?? null,
    condition: raw.condition,
    version: raw.product.version,
    completeScenarioCounts: scenarios.every(
      (row) => row.trials >= 9 && row.rounds.length === 9,
    ),
    resourceQualification:
      raw.environmentInvalid || raw.resourceFinal?.errors.length
        ? "invalid"
        : raw.resourcePreflight && raw.resourceFinal
          ? "no resource errors observed"
          : "consult supplemental review",
    method: {
      rendererTimestampErrorBoundMs: rendererTimeErrorMs,
      focus:
        "First observed departure or different element focus; native poll intervals are used only with bounded IPC clocks. Negative intervals are retained rather than clamped.",
      visibility:
        "Last preserved false sample to first true sample; the nominal 25 ms interval is not substituted for missing polls.",
      predicate:
        "Fresh sentinel after the five-second observation; it does not establish the predicate at the first focus transition.",
      provider:
        "Actual command-associated request candidates, client/server causal clock bounds and strict containment of the j keydown. Ambiguity remains explicit.",
    },
    scenarios,
    trials,
  };
}

if (process.argv[1] && resolve(process.argv[1]) === import.meta.filename) {
  const [file, output] = process.argv.slice(2);
  const bytes = readFileSync(file),
    raw = JSON.parse(bytes);
  assert.ok(raw.finished, "finish the run before creating a retained analysis");
  const review = {
    rawSha256: createHash("sha256").update(bytes).digest("hex"),
    ...analyzeFocus(raw),
  };
  writeFileSync(output, JSON.stringify(review, null, 2) + "\n", { flag: "wx" });
  console.log(
    JSON.stringify({
      trials: review.trials.length,
      completeScenarioCounts: review.completeScenarioCounts,
      resourceQualification: review.resourceQualification,
    }),
  );
}
