import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve, sep } from "node:path";
import { createHash } from "node:crypto";

// The initial frozen V-b batch retained offsets before path redaction. Recover
// exact trial fragments from its retained logs without rewriting raw evidence.
const [file, sandbox, output] = process.argv.slice(2);
const bytes = readFileSync(file),
  raw = JSON.parse(bytes),
  root = resolve(sandbox);
assert.equal(raw.status, "remap-recorded");
const redact = (text) =>
  text.replaceAll(root, "$S1_SANDBOX").replaceAll(process.env.HOME, "$HOME");
const originals = new Map();
for (const trace of raw.vimTrace) {
  const path = resolve(root, trace.file);
  assert.ok(path.startsWith(root + sep));
  const buffer = readFileSync(path).subarray(0, trace.bytes);
  assert.equal(buffer.length, trace.bytes);
  assert.equal(
    redact(buffer.toString("utf8")),
    trace.text,
    "retained log differs from the raw trace after identical redaction",
  );
  originals.set(trace.file, buffer);
}
const fragments = raw.trials.map((trial) => ({
  index: trial.index,
  fragments: trial.traceOffsets.after.map((after) => {
    const before = trial.traceOffsets.before.find(
      (item) => item.file === after.file,
    );
    const source = originals.get(after.file);
    const complete = Boolean(
      before &&
      source &&
      before.bytes <= after.bytes &&
      source.length >= after.bytes,
    );
    return {
      file: after.file,
      complete,
      text: complete
        ? redact(source.subarray(before.bytes, after.bytes).toString("utf8"))
        : null,
    };
  }),
}));
writeFileSync(
  output,
  JSON.stringify(
    {
      rawSha256: createHash("sha256").update(bytes).digest("hex"),
      verification:
        "Original log prefixes reproduce raw.vimTrace exactly after the runner's path redaction; fragments use the original byte offsets before redaction",
      fragments,
    },
    null,
    2,
  ) + "\n",
  { flag: "wx" },
);
console.log(JSON.stringify({ trials: fragments.length }));
