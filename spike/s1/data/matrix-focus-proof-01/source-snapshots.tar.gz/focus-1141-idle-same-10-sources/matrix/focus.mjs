import assert from "node:assert/strict";
import { fork } from "node:child_process";
import { readFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";
import { focusScenarios } from "./focus-scenarios.mjs";
import { clockSamples } from "./observer.mjs";

const catalog = JSON.parse(
  readFileSync(new URL("./catalog.json", import.meta.url)),
);
const fixtureText = "alpha beta gamma\ndelta epsilon zeta\neta theta iota\n";
const chord = (key) => (key === "/" ? "slash" : key);
export function focusKind(target) {
  if (!target) return "other";
  if (target.dialog) return "dialog";
  if (
    target.rename ||
    target.quickInput ||
    target.searchQuery ||
    target.scmInput ||
    (["INPUT", "TEXTAREA"].includes(target.tag) && !target.editor)
  )
    return "text input";
  if (
    target.actionList ||
    target.explorer ||
    target.openEditors ||
    target.scm ||
    ["tree", "list", "listbox"].includes(target.role)
  )
    return "list or tree";
  if (target.hover) return "other";
  return target.editor ? "editor text" : "other";
}

async function nativeRecorder(environment) {
  assert.match(environment.DISPLAY ?? "", /^:\d+$/);
  const child = fork(new URL("./native-focus.cjs", import.meta.url), {
    env: environment,
    stdio: ["ignore", "ignore", "ignore", "ipc"],
  });
  let final, failure;
  child.on("error", (error) => {
    failure = error;
  });
  const ready = await new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error("native focus recorder did not start")),
      5000,
    );
    child.once("error", reject);
    child.on("message", (message) => {
      if (message.ready) {
        clearTimeout(timer);
        resolve(message);
      } else final = message;
    });
  });
  return {
    ready,
    async stop() {
      if (failure) throw failure;
      const exited = new Promise((resolve) => child.once("exit", resolve));
      child.send("stop");
      await exited;
      assert.ok(final, "native focus samples missing");
      return final;
    },
  };
}

export async function runFocus({
  result,
  call,
  inject,
  settled,
  noPending,
  save,
  observer,
  phase,
  workspace,
  xdo,
  window,
  check,
  until,
  environment,
}) {
  result.scope =
    "S1 #7 focus and provider observations; nine trials per scenario/condition, all outcomes retained";
  result.focusProtocol = {
    scenarios: focusScenarios(catalog),
    trialsPerScenario: 9,
    entry:
      "Confirm root and any intermediate prefix before the final leaf key. This isolates command/focus behavior and is not an ordinary unpaused entry qualification.",
    delayedKey:
      "Final leaf key and j use one XTEST batch, with no provider/command/focus wait between them.",
    observation:
      "Five seconds from command start, using bounded host clock offsets. Passive DOM events, 25 ms UI-state polling and an independent 25 ms X focus poller.",
    predicate:
      "vim.mode =~ /^(Normal|Visual)/ && (editorTextFocus || !inputFocus)",
    configure:
      "Record the initial five-second dialog interval, then select Configure and observe a separate five-second follow-up. Do not relabel the dialog as the first input destination.",
  };
  for (const scenario of result.focusProtocol.scenarios)
    for (let round = 0; round < 9; round++) {
      check();
      // All documents belong to this disposable sandbox. Escape dismisses a
      // pending rename/dialog before fixture saving and replacement.
      inject(["Escape", "Escape"]);
      await sleep(100);
      const trial = {
        index: result.trials.length,
        scenario: scenario.id,
        round,
        errors: [],
        inconclusive: [],
      };
      result.lastFocusAttempt = trial;
      trial.fixture = await call("focusSetup", {
        scenario,
        trial: scenario.id + ":" + round,
        workspace,
        fixtureText,
      });
      if (trial.fixture.needsScmRowFocus) {
        await call("command", { command: "workbench.view.scm" });
        const row = await until(
          async () =>
            observer.evaluate(`(()=>{
        const row=[...document.querySelectorAll('.scm-view .monaco-list-row')].find(node=>node.textContent.includes('scm-change.txt'));
        if(!row)return null;const r=row.getBoundingClientRect();return r.width&&r.height?{x:r.x+r.width/2,y:r.y+r.height/2,scale:devicePixelRatio}:null;
      })()`),
          "SCM resource row missing",
        );
        assert.equal(row.scale, 1);
        xdo([
          "mousemove",
          "--window",
          window,
          String(Math.round(row.x)),
          String(Math.round(row.y)),
          "click",
          "1",
        ]);
        await sleep(100);
        trial.fixture.scmFocused = await observer.read();
        assert.equal(
          focusKind(trial.fixture.scmFocused.active),
          "list or tree",
        );
        await call("command", {
          command: "workbench.action.focusActiveEditorGroup",
        });
      }
      if (scenario.state === "visible") {
        await until(
          async () => (await observer.read()).widgets.hover,
          "pre-existing hover did not appear",
        );
      }
      await call("clearLeader");
      inject(["ctrl+alt+9"]);
      trial.before = await settled();
      assert.equal(trial.before.mode, 0);
      assert.ok(noPending(trial.before));
      assert.equal(trial.before.sentinel, "normal-editor-capture-off");
      trial.entryPhaseDelayMs = await phase();
      inject(["space"]);
      trial.entry = await settled();
      inject(["ctrl+alt+9"]);
      trial.root = await settled();
      assert.ok(
        trial.root.leader.active &&
          trial.root.sentinel === "normal-editor-capture-on",
      );
      const prefix = scenario.leaf.keys.slice(0, -1);
      if (prefix.length) {
        inject(prefix.map(chord));
        trial.prefix = await settled();
        assert.deepEqual(trial.prefix.leader.prefix, prefix);
        assert.ok(trial.prefix.leader.active);
      }
      trial.clocksBefore = {
        renderer: await clockSamples(() => observer.clock()),
        hosts: await clockSamples(() => call("clock")),
      };
      trial.rendererBefore = await observer.begin();
      await observer.beginFocus();
      const native = await nativeRecorder(environment);
      let recorderStopped = false;
      try {
        trial.phaseDelayMs = await phase();
        trial.injectedAt = performance.now();
        inject([
          chord(scenario.leaf.keys.at(-1)),
          ...(scenario.delayed ? ["j"] : []),
        ]);
        trial.injectionFinishedAt = performance.now();
        const initial = await until(
          async () => {
            const state = await call("snapshot");
            return (
              state.leader.events.some(
                (event) => event.type === "leaf-start",
              ) && state
            );
          },
          "confirmed prefix did not dispatch the leaf",
          2000,
        );
        trial.commandStart = initial.leader.events.find(
          (event) => event.type === "leaf-start",
        );
        assert.equal(trial.commandStart.id, scenario.leaf.id);
        const upperOffset = Math.min(
          ...trial.clocksBefore.hosts.map(
            (sample) => sample.received - sample.remote.leader.time,
          ),
        );
        trial.observationDeadline = trial.commandStart.t + upperOffset + 5000;
        await sleep(Math.max(0, trial.observationDeadline - performance.now()));
        trial.after = await call("snapshot");
        trial.renderer = await observer.finishFocus();
        trial.native = await native.stop();
        recorderStopped = true;
        trial.providerEvents = await call("focusProviders");
        trial.state = await call("focusState");
        inject(["ctrl+alt+0"]);
        await sleep(100);
        trial.targetSentinel = await call("focusState");
        trial.target = focusKind(trial.renderer.active);
        trial.predicateObserved =
          trial.targetSentinel.sentinel?.sequence ===
          (trial.state.sentinel?.sequence ?? 0) + 1;
        trial.clocksAfter = {
          renderer: await clockSamples(() => observer.clock()),
          hosts: await clockSamples(() => call("clock")),
        };
        if (scenario.state.endsWith("configure")) {
          const button = await observer.evaluate(`(()=>{
          const button=[...document.querySelectorAll('[role="dialog"] button')].find(node=>node.textContent.includes('Configure'));
          if(!button)return null;const r=button.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,scale:devicePixelRatio};
        })()`);
          trial.configure = { button, requestedAt: performance.now() };
          if (button) {
            assert.equal(button.scale, 1);
            await observer.begin();
            await observer.beginFocus();
            xdo([
              "mousemove",
              "--window",
              window,
              String(Math.round(button.x)),
              String(Math.round(button.y)),
              "click",
              "1",
            ]);
            await sleep(5000);
            trial.configure.renderer = await observer.finishFocus();
            trial.configure.state = await call("focusState");
            inject(["ctrl+alt+0"]);
            await sleep(100);
            trial.configure.sentinel = await call("focusState");
          } else
            trial.inconclusive.push(
              "Configure button was not observed in the formatter dialog",
            );
        }
        if (trial.renderer.overflow)
          trial.errors.push("renderer event overflow");
        result.trials.push(trial);
        save();
        console.log(
          `${scenario.id} ${round + 1}/9 focus observations recorded`,
        );
      } finally {
        if (!recorderStopped) trial.native = await native.stop();
        save();
      }
    }
  result.status = "focus-recorded";
}
